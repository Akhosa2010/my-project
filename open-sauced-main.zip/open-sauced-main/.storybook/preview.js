export const parameters = {
    darkMode: {
        stylePreview: true,
        darkClass: "dark",
        lightClass: "light",
    }
};