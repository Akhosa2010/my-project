import styled from "styled-components";

export const Container = styled.div`
  ul {
    margin: 0;
    padding: 0;
  }
`;

export default Container;
