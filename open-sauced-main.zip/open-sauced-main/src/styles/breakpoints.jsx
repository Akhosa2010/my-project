const breakpoints = {
  DESKTOP: 992,
  TABLET: 768,
  PHONE: 376
};

export default breakpoints;
