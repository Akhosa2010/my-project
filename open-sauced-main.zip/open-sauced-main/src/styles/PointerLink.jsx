import styled from "styled-components";

const PointerLink = styled.a`
  cursor: pointer;
`;

export default PointerLink;
