import styled from "styled-components";

const FormColumn = styled.div`
  flex: 1;
`;

export default FormColumn;
