import React from "react";
const ThemeContext = React.createContext("system");

export default ThemeContext;
