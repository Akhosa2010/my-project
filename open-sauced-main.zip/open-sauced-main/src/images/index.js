import face from "./face.png";
import npm from "./npm.png";
import bdougie from "./bdougie.jpg";
import sauce from "./sauce.svg";
import sauced from "./sauced.svg";
import sauceFull from "./pizza-n-sauce.svg";
import pizza from "./pizza.svg";
import gucci from "./gucci.jpg";
import graphql from "./graphql.png";
import gitTrends from "./gitTrends.svg";
import ohno from "./404.svg";
import remirror from "./remirror.svg";
import UseShoppingCart from "./UseShoppingCart.png";
import appInstall from "./appInstall.png";

export {gucci, ohno, bdougie, face, npm, graphql, sauce, sauced, pizza, sauceFull, remirror,
  gitTrends, UseShoppingCart, appInstall
};
