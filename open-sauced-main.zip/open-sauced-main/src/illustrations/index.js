import diary from "./undrawDiary.svg";
import devProductive from "./undrawDevProductivity.svg";
import doneChecking from "./undrawDoneChecking.svg";

export {diary, devProductive, doneChecking};
