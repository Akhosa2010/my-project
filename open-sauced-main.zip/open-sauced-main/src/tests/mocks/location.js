const location = {goalId: "m123", note: "asdfgh"};
export default location;
