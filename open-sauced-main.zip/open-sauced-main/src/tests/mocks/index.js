import match from "./match";
import location from "./location";
import data from "./data";
import LocalStorageMock from "./localStorage";

export {match, data, location, LocalStorageMock};
